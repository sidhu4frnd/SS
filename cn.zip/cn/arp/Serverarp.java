import java.io.*;
import java.net.*;
import java.util.*;

class Serverarp
{
public static void main(String args[]) throws Exception
{int i;
try
{
ServerSocket ss=new ServerSocket(9999);
Socket s=ss.accept();

DataInputStream din=new DataInputStream(s.getInputStream());
DataOutputStream dout=new DataOutputStream(s.getOutputStream());
String str=(String)din.readUTF();
String ip[]={"165.165.80.80","165.165.79.1"};
String mac[]={"6A:08:AA:C2","8A:BC:E3:FA"};
for( i=0;i<ip.length;i++)
{
if(str.equals(ip[i]))
{
break;
}
}
dout.writeUTF(mac[i]);
dout.flush();
dout.close();
ss.close();
}

catch(Exception e)
{
System.out.println(e);
}
}
}
