import java.io.*;
import java.net.*;
import java.util.*;
class Clientarp
{
public static void main(String args[]) throws Exception

{
try
{

BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
Socket s=new Socket("localhost",9999);
DataInputStream din=new DataInputStream(s.getInputStream());
DataOutputStream dout=new DataOutputStream(s.getOutputStream());
System.out.println("Enter the Logical address(IP):");

String str1=br.readLine();
dout.writeUTF(str1);
String str=(String)din.readUTF();
System.out.println("The Physical Address is: "+str);
s.close();
}
catch (Exception e)
{
System.out.println(e);

}
}
}
